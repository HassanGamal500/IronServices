<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AppController extends Controller
{
    public function __construct(Request $request){
        languageApi($request->language_id);
    }

    public function histories(Request $request) {
        $array= array();
        $validator = validator()->make($request->all(), [
            'user_id' => 'required',
        ]);

        if ($validator->fails()){
            $response = [
                'status' => 0,
                'message' => $validator->errors()->first(),
                'data' => []
            ];
            return response()->json($response);
        }

        $orders = DB::table('orders')
            ->where('user_id', '=', $request->user_id)
            ->select('order_id', 'order_detail', 'status_id', 'service_id', 'orders.created_at')
            ->orderBy('orders.created_at', 'desc')
            ->get();


        foreach ($orders as $order){
            $order->service_id = $request->service_id;
            $rate = DB::table('rates')
                ->where('service_id', '=', $order->service_id)
                ->where('user_id', '=', $request->user_id)
                ->where('order_id', '=', $order->order_id)
                ->count();
            if ($rate > 0){
                $order->isRate = 1;
            } else {
                $order->isRate = 0;
            }
//            $array[strtotime($order->created_at)] = $order;
//            $array[] = $order;
        }
//        krsort($array);
//        foreach($array as $value){
//            $allData[]=$value;
//        }

        // dd($array);
        if ($orders){
            $response = [
                'status' => 1,
                'message' => 'successful',
                'data' => $orders
            ];
        } else {
            $response = [
                'status' => 1,
                'message' => 'successful',
                'data' => []
            ];
        }

        return response()->json($response);
    }

    public function notifications(Request $request){
        $validator = validator()->make($request->all(), [
            'user_id' => 'required',
        ]);

        if ($validator->fails()){
            $response = [
                'status' => 0,
                'message' => $validator->errors()->first(),
                'data' => []
            ];
            return response()->json($response);
        }

        $array = array();
        $notifications = DB::table('notifications')
            ->where('user_id', '=', $request->user_id)
            ->orwhere('user_id', '=', 0)
            ->select('notification_name','notification_content', 'notification_image', 'created_at')
            ->orderBy('notification_id', 'desc')
            ->get();

        if (!empty($notifications)){
            $response = [
                'status' => 1,
                'message' => 'Successful',
                'data' => $notifications
            ];
        } else {
            $response = [
                'status' => 1,
                'message' => 'successful',
                'data' => []
            ];
        }

        return response()->json($response);

    }

    public function rates(Request $request) {
        $validator = validator()->make($request->all(), [
            'star' => 'required',
            'comment' => 'required',
            'user_id' => 'required',
            'service_id' => 'required',
            'order_id' => 'required'
        ]);

        if ($validator->fails()){
            $response = [
                'status' => 0,
                'message' => $validator->errors()->first(),
                'data' => []
            ];
            return response()->json($response);
        }

        $rate = DB::table('rates')
            ->insert([
                'rate_star' => $request->star,
                'rate_content' => $request->comment,
                'user_id' => $request->user_id,
                'type' => $request->service_id,
                'reserve_id' => $request->order_id
            ]);

        if($rate) {
            $response = [
                'status' => 1,
                'message' => 'successful',
                'data' => $rate
            ];
        } else {
            $response = [
                'status' => 1,
                'message' => 'successful',
                'data' => []
            ];
        }

        return response()->json($response);
    }

    public function allRates(Request $request) {
        $validator = validator()->make($request->all(), [
            'service_id' => 'required',
        ]);

        if ($validator->fails()){
            $response = [
                'status' => 0,
                'message' => $validator->errors()->first(),
                'data' => []
            ];
            return response()->json($response);
        }

        $rates = DB::table('rates')
            ->join('users', 'users.id', '=', 'rates.user_id')
            ->where('service_id', '=', $request->service_id)
            ->select('rate_star', 'rate_content', 'name', 'image')
            ->get();

        if($rates) {
            $response = [
                'status' => 1,
                'message' => 'successful',
                'data' => $rates
            ];
        } else {
            $response = [
                'status' => 1,
                'message' => 'successful',
                'data' => []
            ];
        }

        return response()->json($response);
    }

    public function orderDetail(Request $request)
    {
        $validator = validator()->make($request->all(), [
            'service_id' => 'required',
            'order_id' => 'required'
        ]);

        if ($validator->fails()) {
            $response = [
                'status' => 0,
                'message' => $validator->errors()->first(),
                'data' => []
            ];
            return response()->json($response);
        }

        $orders = DB::table('orders')
            ->join('status_description', 'status_description.status_id', '=', 'orders.status_id')
            ->join('history_status', 'history_status.status_id', '=', 'orders.status_id')
            ->select('orders.status_id', 'status_name', 'comment', 'order_detail', 'order_latitude', 'order_longitude')
            ->get();

        foreach ($orders as $order){
            $images = DB::table('order_image')->where('order_id', '=', $request->order_id)->get();
            $order->images = $images;
        }

        if($orders) {
            $response = [
                'status' => 1,
                'message' => 'successful',
                'data' => $orders
            ];
        } else {
            $response = [
                'status' => 1,
                'message' => 'successful',
                'data' => []
            ];
        }

        return response()->json($response);
    }
}
