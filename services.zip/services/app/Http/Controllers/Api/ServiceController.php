<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ServiceController extends Controller
{
    public function __construct(Request $request){
        languageApi($request->language_id);
    }

    public function home(Request $request){
        $validator= validator()->make($request->all(),[
            'service_id' => 'required',
        ]);

        if ($validator->fails()){
            $response = [
                'status' => 0,
                'message' => $validator->errors()->first(),
                'data' => []
            ];
            return response()->json($response);
        }

        $services = DB::table('administration')
//            ->join('services', 'services.service_id', '=', 'administration.service_id')
//            ->join('service_description', 'service_description.service_id', '=', 'services.service_id')
            ->select('id', 'name')
//            ->where('language_id', '=', language())
            ->get();

        foreach ($services as $service){
            $banners = DB::table('banners')
                ->where('admin_id', '=', $service->id)
                ->select('banner_image')
                ->get();
            $service->banners = $banners;
            $categories = DB::table('categories')
                ->join('category_description', 'category_description.category_id', '=', 'categories.category_id')
                ->where('admin_id', '=', $service->id)
                ->where('language_id', '=', language())
                ->select('category_name', 'category_image')
                ->limit(4)
                ->get();
            $service->categories = $categories;
            $products = DB::table('products')
                ->join('product_description', 'product_description.product_id', '=', 'products.product_id')
                ->join('categories', 'categories.category_id', '=', 'products.category_id')
                ->where('language_id', '=', language())
                ->where('admin_id', '=', $service->id)
                ->select('product_name', 'product_image', 'price', 'discount')
                ->limit(4)
                ->get();
            $service->products = $products;
        }

        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $services
        ];
        return response()->json($response);
    }

    public function products(Request $request) {
        $validator= validator()->make($request->all(),[
            'service_id' => 'required',
        ]);

        if ($validator->fails()){
            $response = [
                'status' => 0,
                'message' => $validator->errors()->first(),
                'data' => []
            ];
            return response()->json($response);
        }

        $products = DB::table('products')
            ->join('product_description', 'product_description.product_id', '=', 'products.product_id')
            ->join('categories', 'categories.category_id', '=', 'products.category_id')
            ->where('language_id', '=', language())
            ->where('admin_id', '=', $request->service_id)
            ->select('product_name', 'product_image', 'price', 'discount')
            ->get();

        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $products
        ];
        return response()->json($response);
    }

    public function detailProduct(Request $request) {
        $validator= validator()->make($request->all(),[
            'service_id' => 'required',
            'product_id' => 'required'
        ]);

        if ($validator->fails()){
            $response = [
                'status' => 0,
                'message' => $validator->errors()->first(),
                'data' => []
            ];
            return response()->json($response);
        }

        $products = DB::table('products')
            ->join('product_description', 'product_description.product_id', '=', 'products.product_id')
            ->join('brand_description', 'brand_description.brand_id', '=', 'products.brand_id')
            ->join('categories', 'categories.category_id', '=', 'products.category_id')
            ->where('products.product_id', '=', $request->product_id)
            ->where('product_description.language_id', '=', language())
            ->where('brand_description.language_id', '=', language())
            ->where('admin_id', '=', $request->service_id)
            ->select('products.product_id', 'product_name', 'product_image', 'price', 'discount',
                'brand_name', 'product_description_part', 'product_description_full')
            ->get();
        foreach ($products as $product){
            $images = DB::table('product_image')->where('product_id', '=', $request->product_id)->get();
            $product->images = $images;
        }

        $response = [
            'status' => 1,
            'message' => 'successful',
            'data' => $products
        ];
        return response()->json($response);
    }

    public function categories(Request $request) {
        $validator= validator()->make($request->all(),[
            'service_id' => 'required',
        ]);

        if ($validator->fails()){
            $response = [
                'status' => 0,
                'message' => $validator->errors()->first(),
                'data' => []
            ];
            return response()->json($response);
        }

        $categories = DB::table('categories')
            ->join('category_description', 'category_description.category_id', '=', 'categories.category_id')
            ->where('admin_id', '=', $request->service_id)
            ->where('language_id', '=', language())
            ->select('category_name', 'category_image')
            ->get();

        $response = [
            'status' => 1,
            'message' => trans('admin.success'),
            'data' => $categories
        ];
        return response()->json($response);
    }
}
