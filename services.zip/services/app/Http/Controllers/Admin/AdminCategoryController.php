<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class AdminCategoryController extends Controller
{
    public function index(){
        $categories = DB::table('categories')
            ->join('category_description', 'category_description.category_id', '=', 'categories.category_id')
            ->where('language_id', '=', language())
            ->select('categories.category_id as id', 'category_name as name', 'category_image as image')
            ->get();
        return view('admin.categories.index', compact('categories'));
    }

    public function storeCategory(Request $request){
        $validator = validator()->make($request->all(), [
            'category_name' => 'required',
            'image' => 'required|image|mimes:jpeg,png,jpg,bmp,gif,svg|max:2048'
        ]);

        if ($validator->fails()) {
            $error = $validator->errors()->first();
            $arr=array('status' => '0', 'data' => [], 'message' => $error);
            return response()->json($arr);
        }

        if ($request->hasFile('image')) {
            $imageName = Storage::disk('edit_path')->putFile('images/category', $request->file('image'));
        } else {
            $imageName = 'images/category/logo_avatar.png';
        }

        $category = DB::table('categories')
            ->insertGetId([
                'category_image' => $imageName,
                'admin_id' => 4
            ]);

        for ($i = 1; $i <= 2; $i++){
            $description = DB::table('category_description')
                ->insert([
                    'category_name' => $request->category_name[$i],
                    'language_id' => $i,
                    'category_id' => $category
                ]);
        }

        $categories = DB::table('categories')
            ->join('category_description', 'category_description.category_id', '=', 'categories.category_id')
            ->where('language_id', '=', language())
            ->select('categories.category_id as id', 'category_name as name', 'category_image as image')
            ->get();
        $arr=array('status'=>'1','data'=>$categories);
        return response()->json($arr);
    }

    public function editCategory(Request $request) {
        $categories = DB::table('categories')
            ->join('category_description', 'category_description.category_id', '=', 'categories.category_id')
            ->where('categories.category_id', '=', $request->id)
            ->select('categories.category_id as id', 'category_name as name', 'category_image as image')
            ->get();
        return response()->json($categories);
    }

    public function updateCategory(Request $request) {
        $validator = validator()->make($request->all(), [
            'category_name' => 'required',
        ]);

        if ($validator->fails()) {
            $error = $validator->errors()->first();
            $arr=array('status' => '0', 'data' => [], 'message' => $error);
            return response()->json($arr);
        }

        if ($request->hasFile('image')) {
            $imageName = Storage::disk('edit_path')->putFile('images/category', $request->file('image'));
        } else {
            $imageName = $request->old_image;
        }

        $category = DB::table('categories')
            ->where('category_id', '=', $request->id)
            ->update([
                'category_image' => $imageName,
                'admin_id' => 4
            ]);

        for ($i = 1; $i <= 2; $i++){
            $description = DB::table('category_description')
                ->where('category_id', '=', $request->id)
                ->where('language_id', '=', $i)
                ->update([
                    'category_name' => $request->category_name[$i],
                    'language_id' => $i,
                ]);
        }

        $categories = DB::table('categories')
            ->join('category_description', 'category_description.category_id', '=', 'categories.category_id')
            ->where('language_id', '=', language())
            ->select('categories.category_id as id', 'category_name as name', 'category_image as image')
            ->get();
        $arr=array('status'=>'1','data'=>$categories);
        return response()->json($arr);
    }

    public function destroyCategory(Request $request, $id){
        $service = DB::table('categories')
            ->where('category_id', '=', $id)
            ->delete();
    }
}
