<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;

class AdminUserController extends Controller
{
    public function index(){
        $users = DB::table('users')
            ->select('id', 'name', 'phone', 'email', 'image', 'active')
            ->orderBy('id', 'desc')
            ->get();
        return view('admin.users.index', compact('users'));
    }

    public function addUser(){
        return view('admin.users.create');
    }

    public function storeUser(Request $request) {
        $validator = validator()->make($request->all(), [
            'name' => 'required',
            'phone' => 'required|unique:users',
            'email' => 'required|unique:users|email',
            'password' => 'required|min:8|regex:/^(?=.*?[a-z])(?=.*?[0-9])/',
            'image' => 'required|image|mimes:jpeg,png,jpg,bmp,gif,svg|max:2048',
        ]);

        if ($validator->fails()) {
            $error = $validator->errors()->first();
            return Redirect::back()->withInput($request->all())->with('error', $error);
        }

        if ($request->hasFile('image')) {
            $imageName = Storage::disk('edit_path')->putFile('images/user', $request->file('image'));
        } else {
            $imageName = 'images/user/logo_avatar.png';
        }

        $users = DB::table('users')
            ->insert([
                'name' => $request->name,
                'phone' => convert($request->phone),
                'email' => $request->email,
                'password' => bcrypt($request->password),
                'image' => $imageName,
            ]);

        $allUsers = DB::table('users')->orderBy('id', 'desc')->get();

        $message = App::isLocale('ar') ? 'تم التعديل بنجاح' : 'Updated Successfully';

        return Redirect::back()->with('message', $message);
    }

    public function editUser($id){
        $users = DB::table('users')
            ->select('id', 'name', 'phone', 'email', 'image', 'active')
            ->where('id', '=', $id)
            ->first();
        return view('admin.users.edit', compact('users'));
    }

    public function updateUser(Request $request, $id){
        $validator = validator()->make($request->all(), [
            'name' => 'required',
            'phone' => 'required',
            'email' => 'required|email',
            'password' => 'nullable|min:8|regex:/^(?=.*?[a-z])(?=.*?[0-9])/',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,bmp,gif,svg|max:2048',
            'active' => 'nullable'
        ]);

        if ($validator->fails()) {
            $error = $validator->errors()->first();
            return Redirect::back()->with('error', $error);
        }

        $getUser = User::find($id);
        $allPhone = User::where('phone', convert($request->phone))->where('id', '!=', $id)->first();
        $allEmail = User::where('email', $request->email)->where('id', '!=', $id)->first();

        $users = DB::table('users')
            ->where('id', '=', $id)
            ->update(['name' => $request->name, 'api_token' => Str::random(60)]);

        if ($allPhone) {
            $error = trans('admin.This phone has been taken before');
            return Redirect::back()->with('error', $error);
        } else {
            $getUser->phone = convert($request->phone);
            $getUser->save();
        }

        if ($allEmail) {
            $error = trans('admin.This Email has been taken before');
            return Redirect::back()->with('error', $error);
        } else {
            $getUser->email = $request->email;
            $getUser->save();
        }

        if ($request->password) {
            $users = DB::table('users')
                ->where('id', '=', $id)
                ->update(['password' => bcrypt($request->password),]);
        }

        if ($request->hasFile('image')) {
            if($getUser->image != 'images/user/avatar_user.png'){
                $myFile = base_path($getUser->image);
                File::delete($myFile);
            }

            $imageName = Storage::disk('edit_path')->putFile('images/user', $request->file('image'));

            $users = DB::table('users')
                ->where('id', '=', $id)
                ->update(['image' => $imageName]);
        } else {
            $imageName = $request->old_image;
            $users = DB::table('users')
                ->where('id', '=', $id)
                ->update(['image' => $imageName]);
        }

//        if ($request->gender) {
//            $users = DB::table('users')
//                ->where('id', '=', $id)
//                ->update(['gender' => $request->gender]);
//        }
//
//        if ($request->active == 1) {
//            $users = DB::table('users')
//                ->where('id', '=', $id)
//                ->update(['active' => $request->active]);
//        } else {
//            $users = DB::table('users')
//                ->where('id', '=', $id)
//                ->update(['active' => $request->active]);
//        }

        $message = App::isLocale('ar') ? 'تم التعديل بنجاح' : 'Updated Successfully';

        return Redirect::back()->with('message', $message);
    }

    public function destroyUser(Request $request, $id){
        $getUser = User::find($id);
        if($getUser->image != 'images/user/logo_avatar.png'){
            $myFile = base_path($getUser->image);
            File::delete($myFile);
        }
        $users = DB::table('users')
            ->where('id', '=', $id)
            ->delete();
//        $allUsers = DB::table('users')
//            ->select('id', 'name', 'phone','email', 'image', 'service_id')
//            ->orderBy('id', 'desc')
//            ->get();

//        $table = '';
//        $num = 1;
//        foreach ($allUsers as $allUser){
//            $table = '<tr>';
//            $table .= '<td>'.$num.'</td>';
//            $table .= '<td>'.$allUser->name.'</td>';
//            $table .= '<td>'.$allUser->email.'</td>';
//            $table .= '<td>'.$allUser->phone.'</td>';
//            $table .= '<td><img src="'.asset("$allUser->image").'"></td>';
//            $table .= '<td><a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="'.url(route('edit_user', $allUser->id)).'"><i class="material-icons">mode_edit</i></a></td>';
//            $table .= '<td><a class="btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange alerts" data-url="'.asset('delete_user').'/" data-id="'.$allUser->id.'"><i class="material-icons">clear</i></a></td>';
//            $table .= '</tr>';
//        }
//        return response()->json($table);
    }
}
