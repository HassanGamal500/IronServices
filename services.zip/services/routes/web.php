<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use Illuminate\Support\Facades\App;

Route::get('/lang/{locale}', function ($locale){
    App::setLocale($locale);
    session()->put('locale', $locale);
    return redirect()->back();
});

Route::get('/admin/login', 'Admin\AdminLoginController@showLoginForm')->name('admin.login');
Route::post('/admin/login', 'Admin\AdminLoginController@login')->name('admin.login.post');
Route::post('/admin/logout', 'Admin\AdminLoginController@logout')->name('admin.logout');

Route::group(['namespace' => 'admin', 'middleware' => 'admin'], function (){
    // AJAX
    Route::post('/changeStatus', 'UserController@changeStatus');
    Route::post('/addCoupon', 'CouponController@addCoupon');
    Route::post('/getCoupon', 'CouponController@getCoupon');
    Route::post('/updateCoupon', 'CouponController@updateCoupon');
    Route::post('/addInterest', 'InterestController@addInterest');
    Route::post('/getInterest', 'InterestController@getInterest');
    Route::post('/updateInterest', 'InterestController@updateInterest');
    Route::post('/get_services', 'AdvertisementController@service');
    // Dashboard
    Route::get('/', 'AdminDashboardController@home')->name('dashboard');
    // Users Super Admin
    Route::get('/users', 'AdminUserController@index')->name('all_users');
    Route::get('/add_user', 'AdminUserController@addUser');
    Route::post('/add_user', 'AdminUserController@storeUser')->name('store_user');
    Route::get('/edit_user/{id}', 'AdminUserController@editUser')->name('edit_user');
    Route::post('/edit_user/{id}', 'AdminUserController@updateUser')->name('update_user');
    Route::delete('/delete_user/{id}', 'AdminUserController@destroyUser')->name('delete_user');
    // Services
    Route::get('/services', 'AdminServiceController@index')->name('all_services');
    Route::get('/add_service', 'AdminServiceController@addService');
    Route::post('/add_service', 'AdminServiceController@storeService')->name('store_service');
    Route::get('/edit_service/{id}', 'AdminServiceController@editService')->name('edit_service');
    Route::post('/edit_service/{id}', 'AdminServiceController@updateService')->name('update_service');
    Route::delete('/delete_service/{id}', 'AdminServiceController@destroyService')->name('delete_service');
    //Service Client
    Route::get('/service_client/{id}', 'AdminServiceClientController@index')->name('service_client');
    Route::get('/add_service_client/{id}', 'AdminServiceClientController@addServiceClient')->name('add_service_client');
    Route::post('/add_service_client', 'AdminServiceClientController@storeServiceClient')->name('store_service_client');
    Route::get('/edit_service_client/{id}', 'AdminServiceClientController@editServiceClient')->name('edit_service_client');
    Route::post('/edit_service_client/{id}', 'AdminServiceClientController@updateServiceClient')->name('update_service_client');
    Route::delete('/delete_service_client/{id}', 'AdminServiceClientController@destroyServiceClient')->name('delete_service_client');
    // Cities - AJAX
    Route::get('/cities', 'AdminCityController@index')->name('all_cities');
    Route::post('/add_city', 'AdminCityController@storeCity')->name('store_city');
    Route::post('/edit_city', 'AdminCityController@editCity')->name('edit_city');
    Route::post('/update_city', 'AdminCityController@updateCity')->name('update_city');
    Route::delete('/delete_city/{id}', 'AdminCityController@destroyCity')->name('delete_city');
    // Areas - AJAX
    Route::get('/areas', 'AdminAreaController@index')->name('all_areas');
    Route::post('/add_area', 'AdminAreaController@storeArea')->name('store_area');
    Route::post('/edit_area', 'AdminAreaController@editArea')->name('edit_area');
    Route::post('/update_area', 'AdminAreaController@updateArea')->name('update_area');
    Route::delete('/delete_area/{id}', 'AdminAreaController@destroyArea')->name('delete_area');
    // Categories - AJAX
    Route::get('/categories', 'AdminCategoryController@index')->name('all_categories');
    Route::post('/add_category', 'AdminCategoryController@storeCategory')->name('store_category');
    Route::post('/edit_category', 'AdminCategoryController@editCategory')->name('edit_category');
    Route::post('/update_category', 'AdminCategoryController@updateCategory')->name('update_category');
    Route::delete('/delete_category/{id}', 'AdminCategoryController@destroyCategory')->name('delete_category');
    // Brands - AJAX
    Route::get('/brands', 'AdminBrandController@index')->name('all_brands');
    Route::post('/add_brand', 'AdminBrandController@storeBrand')->name('store_brand');
    Route::post('/edit_brand', 'AdminBrandController@editBrand')->name('edit_brand');
    Route::post('/update_brand', 'AdminBrandController@updateBrand')->name('update_brand');
    Route::delete('/delete_brand/{id}', 'AdminBrandController@destroyBrand')->name('delete_brand');
    // Pages
    Route::get('pages', 'PageController@index');
    Route::get('/edit_page/{id}', 'PageController@edit')->name('edit_page');
    Route::post('/edit_page/{id}', 'PageController@update')->name('update_page');
    Route::delete('/delete_page/{id}', 'PageController@destroy')->name('delete_page');
    // Notification
    Route::get('notifications', 'NotificationController@index');
    Route::get('/add_notification', 'NotificationController@create');
    Route::post('/add_notification', 'NotificationController@store')->name('store_notification');
    Route::delete('/delete_notification/{id}', 'NotificationController@destroy')->name('delete_notification');
    // contact us
    Route::get('contact', 'ContactController@index');
    Route::post('contact', 'ContactController@store')->name('store_contact');
    Route::get('contacts', 'ContactController@showAll')->name('contacts');
    Route::post('contact_notify', 'ContactController@contact_notify')->name('contact_notify');
    Route::get('get_contact', 'ContactController@getContacts')->name('contact_count');
    Route::delete('contact_delete/{id}', 'ContactController@destroy')->name('contact_delete');
    // rates
    Route::get('rates', 'RateController@index');
    Route::delete('rate_delete/{id}', 'RateController@destroy')->name('rate_delete');
    // Images
    Route::get('images', 'ImageController@index');
    Route::get('/add_image', 'ImageController@create');
    Route::post('/add_image', 'ImageController@store')->name('store_image');
    Route::get('/edit_image/{id}', 'ImageController@edit')->name('edit_image');
    Route::post('/edit_image/{id}', 'ImageController@update')->name('update_image');
    Route::delete('/delete_image/{id}', 'ImageController@destroy')->name('delete_image');
    // Advertisements
    Route::get('advertisements', 'AdvertisementController@index');
    Route::get('/add_advertisement', 'AdvertisementController@create');
    Route::post('/add_advertisement', 'AdvertisementController@store')->name('store_advertisement');
    Route::get('/edit_advertisement/{id}', 'AdvertisementController@edit')->name('edit_advertisement');
    Route::post('/edit_advertisement/{id}', 'AdvertisementController@update')->name('update_advertisement');
    Route::delete('/delete_advertisement/{id}', 'AdvertisementController@destroy')->name('delete_advertisement');
    // Interests
    Route::get('interests', 'InterestController@index');
    Route::get('/add_interest', 'InterestController@create');
    Route::post('/add_interest', 'InterestController@store')->name('store_interest');
    Route::get('/edit_interest/{id}', 'InterestController@edit')->name('edit_interest');
    Route::post('/edit_interest/{id}', 'InterestController@update')->name('update_interest');
    Route::delete('/delete_interest/{id}', 'InterestController@destroy')->name('delete_interest');
    // Reservations
    Route::get('reserve_hospital/{id}', 'ReservationController@hospital')->name('hospital_reserve');
    Route::get('reserve_clinic/{id}', 'ReservationController@clinic')->name('clinic_reserve');
    Route::get('reserve_restaurant/{id}', 'ReservationController@restaurant')->name('restaurant_reserve');
    Route::get('reserve_catering/{id}', 'ReservationController@catering')->name('catering_reserve');
    Route::get('show_reserve_hospital/{id}', 'ReservationController@showReserveHospital')->name('hospital_show');
    Route::get('show_reserve_clinic/{id}', 'ReservationController@showReserveClinic')->name('clinic_show');
    Route::get('show_reserve_restaurant/{id}', 'ReservationController@showReserveRestaurant')->name('restaurant_show');
    Route::get('show_reserve_catering/{id}', 'ReservationController@showReserveCatering')->name('catering_show');
    Route::post('reserve_notify', 'ReservationController@reserve_notify')->name('reserve_notify');
    Route::get('reserve_count', 'ReservationController@reserve_count')->name('reserve_count');
    // Admin Controll
    Route::get('/edit_profile/{id}', 'AdminLoginController@editProfile')->name('edit_profile');
    Route::post('/edit_profile/{id}', 'AdminLoginController@updateProfile')->name('update_profile');
    Route::get('/edit_hospital_admin', 'HospitalController@editAdmin')->name('edit_hospital_admin');
    Route::get('/edit_clinic_admin', 'ClinicController@editAdmin')->name('edit_clinic_admin');
    Route::get('/edit_restaurant_admin', 'RestaurantController@editAdmin')->name('edit_restaurant_admin');
    Route::get('/edit_catering_admin', 'CateringController@editAdmin')->name('edit_catering_admin');
    Route::get('reserve_hospital_admin', 'ReservationController@hospitalAdmin')->name('hospital_reserve_admin');
    Route::get('reserve_clinic_admin', 'ReservationController@clinicAdmin')->name('clinic_reserve_admin');
    Route::get('reserve_restaurant_admin', 'ReservationController@restaurantAdmin')->name('restaurant_reserve_admin');
    Route::get('reserve_catering_admin', 'ReservationController@cateringAdmin')->name('catering_reserve_admin');
    Route::post('status/{id}', 'ReservationController@updateState')->name('status');

});


