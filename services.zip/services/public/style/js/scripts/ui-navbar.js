/*
* Navbar - Sidenav
*/
$(function() {
	$(".dropdown-button").dropdown();
	$(".button-collapse").sideNav();
});