<?php $__env->startSection('page_title'); ?>
    <?php echo e(getServiceName($id)->service_name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section id="content">
        <!--breadcrumbs start-->
        <div id="breadcrumbs-wrapper">
            <!-- Search for small screen -->
            <div class="header-search-wrapper grey lighten-2 hide-on-large-only">
                <input type="text" name="Search" class="header-search-input z-depth-2" placeholder="Explore Materialize">
            </div>
            <div class="container">
                <div class="row">
                    <div class="col s10 m6 l6">
                        <h5 class="breadcrumbs-title"><?php echo e(getServiceName($id)->service_name); ?></h5>
                        <ol class="breadcrumbs">
                            <li><a href="<?php echo e(url('/')); ?>"><?php echo e(trans('admin.dashboard')); ?></a></li>
                            <li class="active"><?php echo e(getServiceName($id)->service_name); ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <!--start container-->
        <div class="container">
            <div class="section">
                <div class="divider"></div>
                <!--DataTables example-->
                <div id="table-datatables">
                    <h4 class="header"><?php echo e(trans('admin.all')); ?> <?php echo e(getServiceName($id)->service_name); ?></h4>
                    <div class="row">
                        <div class="col s12">
                            <table id="data-table-simple" class="responsive-table display datatableUser" cellspacing="0">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th><?php echo e(trans('admin.name')); ?></th>
                                    <th><?php echo e(trans('admin.email')); ?></th>
                                    <th><?php echo e(trans('admin.phone')); ?></th>
                                    <th><?php echo e(trans('admin.image')); ?></th>
                                    <th><?php echo e(trans('admin.edit')); ?></th>
                                    <th><?php echo e(trans('admin.delete')); ?></th>
                                </tr>
                                </thead>
                                <tfoot>
                                <tr>
                                    <th>ID</th>
                                    <th><?php echo e(trans('admin.name')); ?></th>
                                    <th><?php echo e(trans('admin.email')); ?></th>
                                    <th><?php echo e(trans('admin.phone')); ?></th>
                                    <th><?php echo e(trans('admin.image')); ?></th>
                                    <th><?php echo e(trans('admin.edit')); ?></th>
                                    <th><?php echo e(trans('admin.delete')); ?></th>
                                </tr>
                                </tfoot>
                                <tbody class="refresh">
                                <?php $__currentLoopData = $serviceClient; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="<?php echo e($service->id); ?>">
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($service->name); ?></td>
                                    <td><?php echo e($service->email); ?></td>
                                    <td><?php echo e($service->phone); ?></td>
                                    <td><img src="<?php echo e(asset('$service->image')); ?>"></td>
                                    <td>
                                        <a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan" href="<?php echo e(url(route('edit_service_client', $service->id))); ?>">
                                            <i class="material-icons">mode_edit</i>
                                        </a>
                                    </td>
                                    <td>
                                        <a class="btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange alerts" data-url="<?php echo e(asset('delete_service_client')); ?>/" data-id="<?php echo e($service->id); ?>">
                                            <i class="material-icons">clear</i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end container-->
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('common.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\services\resources\views/admin/service_client/index.blade.php ENDPATH**/ ?>