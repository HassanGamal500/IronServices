<aside id="left-sidebar-nav" class="nav-expanded nav-lock nav-collapsible">
    <div class="brand-sidebar">
        <h1 class="logo-wrapper">
            <a href="index.html" class="brand-logo darken-1">
                <img src="<?php echo e(asset('style/images/logo/materialize-logo.png')); ?>" alt="materialize logo">
                <span class="logo-text hide-on-med-and-down">Services</span>
            </a>
            <a href="#" class="navbar-toggler">
                <i class="material-icons">radio_button_checked</i>
            </a>
        </h1>
    </div>
    <ul id="slide-out" class="side-nav fixed leftside-navigation">
        <li class="no-padding">
            <ul class="collapsible" data-collapsible="accordion">
                <li class="bold">
                    <a href="<?php echo e(url('/')); ?>" class="waves-effect waves-cyan">
                        <i class="material-icons">mail_outline</i>
                        <span class="nav-text"><?php echo e(trans('admin.dashboard')); ?></span>
                    </a>
                </li>
                <li class="bold">
                    <a class="collapsible-header waves-effect waves-cyan">
                        <i class="material-icons">dvr</i>
                        <span class="nav-text"><?php echo e(trans('admin.users')); ?></span>
                    </a>
                    <div class="collapsible-body">
                        <ul>
                            <li>
                                <a href="<?php echo e(url('/users')); ?>">
                                    <i class="material-icons">keyboard_arrow_right</i>
                                    <span><?php echo e(trans('admin.users')); ?></span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('/add_user')); ?>">
                                    <i class="material-icons">keyboard_arrow_right</i>
                                    <span><?php echo e(trans('admin.add user')); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>
                <li class="bold">
                    <a class="collapsible-header waves-effect waves-cyan">
                        <i class="material-icons">dvr</i>
                        <span class="nav-text"><?php echo e(trans('admin.services')); ?></span>
                    </a>
                    <div class="collapsible-body">
                        <ul>
                            <li>
                                <a href="<?php echo e(url('/services')); ?>">
                                    <i class="material-icons">keyboard_arrow_right</i>
                                    <span><?php echo e(trans('admin.services')); ?></span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('/add_service')); ?>">
                                    <i class="material-icons">keyboard_arrow_right</i>
                                    <span><?php echo e(trans('admin.add service')); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>
                <?php $__currentLoopData = services(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="bold">
                    <a class="collapsible-header waves-effect waves-cyan">
                        <i class="material-icons">dvr</i>
                        <span class="nav-text"><?php echo e($service->service_name); ?></span>
                    </a>
                    <div class="collapsible-body">
                        <ul>
                            <li>
                                <a href="<?php echo e(url(route('service_client', $service->service_id))); ?>">
                                    <i class="material-icons">keyboard_arrow_right</i>
                                    <span><?php echo e($service->service_name); ?></span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(url(route('add_service_client', $service->service_id))); ?>">
                                    <i class="material-icons">keyboard_arrow_right</i>
                                    <span><?php echo e(trans('admin.add')); ?> <?php echo e($service->service_name); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <li class="bold">
                    <a href="<?php echo e(url('/cities')); ?>" class="waves-effect waves-cyan">
                        <i class="material-icons">mail_outline</i>
                        <span class="nav-text"><?php echo e(trans('admin.cities')); ?></span>
                    </a>
                </li>
                <li class="bold">
                    <a href="<?php echo e(url('/areas')); ?>" class="waves-effect waves-cyan">
                        <i class="material-icons">mail_outline</i>
                        <span class="nav-text"><?php echo e(trans('admin.areas')); ?></span>
                    </a>
                </li>
                <li class="bold">
                    <a href="<?php echo e(url('/categories')); ?>" class="waves-effect waves-cyan">
                        <i class="material-icons">mail_outline</i>
                        <span class="nav-text"><?php echo e(trans('admin.categories')); ?></span>
                    </a>
                </li>
                <li class="bold">
                    <a href="<?php echo e(url('/brands')); ?>" class="waves-effect waves-cyan">
                        <i class="material-icons">mail_outline</i>
                        <span class="nav-text"><?php echo e(trans('admin.brands')); ?></span>
                    </a>
                </li>
            </ul>
        </li>
    </ul>
    <a href="#" data-activates="slide-out" class="sidebar-collapse btn-floating btn-medium waves-effect waves-light hide-on-large-only gradient-45deg-light-blue-cyan gradient-shadow">
        <i class="material-icons">menu</i>
    </a>
</aside>
<?php /**PATH C:\xampp\htdocs\services\resources\views/common/sidebar.blade.php ENDPATH**/ ?>