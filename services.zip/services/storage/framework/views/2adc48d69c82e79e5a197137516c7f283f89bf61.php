Hi <strong><?php echo e($name); ?></strong>,

<p><?php echo e($body); ?></p>
<?php /**PATH C:\xampp\htdocs\services\resources\views/email/mail.blade.php ENDPATH**/ ?>