<?php $__env->startSection('page_title'); ?>
    <?php echo e(trans('admin.edit service')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section id="content">
        <!--breadcrumbs start-->
        <div id="breadcrumbs-wrapper">
            <!-- Search for small screen -->
            <div class="header-search-wrapper grey lighten-2 hide-on-large-only">
                <input type="text" name="Search" class="header-search-input z-depth-2" placeholder="Explore Materialize">
            </div>
            <div class="container">
                <div class="row">
                    <div class="col s10 m6 l6">
                        <h5 class="breadcrumbs-title"><?php echo e(trans('admin.edit service')); ?></h5>
                        <ol class="breadcrumbs">
                            <li><a href="<?php echo e(trans('/')); ?>"><?php echo e(trans('admin.dashboard')); ?></a></li>
                            <li class="active"><?php echo e(trans('admin.edit service')); ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <!--start container-->
        <div class="container">
            <div class="section">
                <div class="row">
                    <div class="col s12">
                        <div class="card-panel">
                            <h4 class="header2"><?php echo e(trans('admin.edit service')); ?></h4>
                            <div class="row">
                                <?php if(session()->has('message')): ?>
                                    <div id="card-alert" class="card gradient-45deg-green-teal">
                                        <div class="card-content white-text">
                                            <p>
                                                <i class="material-icons">check</i> <?php echo e(session()->get('message')); ?></p>
                                        </div>
                                        <button type="button" class="close white-text" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>
                                <?php elseif(session()->has('error')): ?>
                                    <div id="card-alert" class="card gradient-45deg-red-pink">
                                        <div class="card-content white-text">
                                            <p>
                                                <i class="material-icons">error</i> <?php echo e(session()->get('error')); ?></p>
                                        </div>
                                        <button type="button" class="close white-text" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>
                                <?php endif; ?>
                                <form class="col s12" method="post" action="<?php echo e(route('update_service', $services[0]->id)); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="input-field col s12">
                                            <i class="material-icons prefix">account_circle</i>
                                            <input id="name3" type="text" name="service_name[1]" value="<?php echo e($services[0]->name); ?>" required>
                                            <label for="first_name"><?php echo e(trans('admin.name')); ?> (<?php echo e(trans('admin.english')); ?>)</label>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="input-field col s12">
                                            <i class="material-icons prefix">account_circle</i>
                                            <input id="name3" type="text" name="service_name[2]" value="<?php echo e($services[1]->name); ?>" required>
                                            <label for="first_name"><?php echo e(trans('admin.name')); ?> (<?php echo e(trans('admin.arabic')); ?>)</label>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="input-field col s12">
                                            <select name="active">
                                                <option value="" disabled selected><?php echo e(trans('admin.activate')); ?></option>
                                                <option value="1" <?php echo e($services[0]->active == 1 ? 'selected' : ''); ?>><?php echo e(trans('admin.active')); ?></option>
                                                <option value="0" <?php echo e($services[0]->active == 0 ? 'selected' : ''); ?>><?php echo e(trans('admin.inactive')); ?></option>
                                            </select>
                                            <label><?php echo e(trans('admin.activate')); ?></label>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="input-field col s12">
                                            <button class="btn cyan waves-effect waves-light right" type="submit" name="action"><?php echo e(trans('admin.submit')); ?>

                                                <i class="material-icons right">send</i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end container-->
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('common.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\services\resources\views/admin/services/edit.blade.php ENDPATH**/ ?>