<footer class="page-footer">
    <div class="footer-copyright">
        <div class="container">
            <span>Copyright ©
              <script type="text/javascript">
                document.write(new Date().getFullYear());
              </script> <a class="grey-text text-darken-2" href="http://themeforest.net/user/pixinvent/portfolio?ref=pixinvent" target="_blank">PIXINVENT</a> All rights reserved.</span>
            <span class="right hide-on-small-only"> Design and Developed by <a class="grey-text text-darken-2" href="https://pixinvent.com/">PIXINVENT</a></span>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\services\resources\views/common/footer.blade.php ENDPATH**/ ?>