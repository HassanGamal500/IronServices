<!-- jQuery Library -->
{{--<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>--}}
{{--<script type="text/javascript" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>--}}
{{--<script type="text/javascript" src="https://cdn.datatables.net/1.10.20/js/dataTables.semanticui.min.js"></script>--}}
{{--<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.3.1/semantic.min.js"></script>--}}
<script type="text/javascript" src="{{asset('style/vendors/jquery-3.2.1.min.js')}}"></script>
<!--materialize js-->
<script type="text/javascript" src="{{asset('style/js/materialize.min.js')}}"></script>
<!--prism-->
<script type="text/javascript" src="{{asset('style/vendors/prism/prism.js')}}"></script>
<!--scrollbar-->
<script type="text/javascript" src="{{asset('style/vendors/perfect-scrollbar/perfect-scrollbar.min.js')}}"></script>
<script type="text/javascript" src="{{asset('style/vendors/sweetalert/dist/sweetalert.min.js')}}"></script>
<!-- data-tables -->
<script type="text/javascript" src="{{asset('style/vendors/data-tables/js/jquery.dataTables.min.js')}}"></script>
<!--data-tables.js - Page Specific JS codes -->
<script type="text/javascript" src="{{asset('style/js/scripts/data-tables.js')}}"></script>
<!-- chartjs -->
<script type="text/javascript" src="{{asset('style/vendors/chartjs/chart.min.js')}}"></script>
<!--plugins.js - Some Specific JS codes for Plugin Settings-->
<script type="text/javascript" src="{{asset('style/js/plugins.js')}}"></script>
<!--extra-components-sweetalert.js - Some Specific JS-->
<script type="text/javascript" src="{{asset('style/js/scripts/extra-components-sweetalert.js')}}"></script>
<!--advanced-ui-modals.js - Some Specific JS codes -->
<script type="text/javascript" src="{{asset('style/js/scripts/advanced-ui-modals.js')}}"></script>
<!--custom-script.js - Add your own theme custom JS-->
<script type="text/javascript" src="{{asset('style/js/custom-script.js')}}"></script>
{{--<script type="text/javascript" src="{{asset('style/js/scripts/dashboard-ecommerce.js')}}"></script>--}}
<!-- Sweet Alert -->
{{--<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>--}}



<script>
    $(document).ready(function() {
        $('#dataTableUser').DataTable();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $(document).on('click', '.alerts', function(e){
            var url = $(this).data("url");
            var id = $(this).data("id");
            e.preventDefault();
            swal({   title: "Are you sure?",
                    text: "You will not be able to recover this imaginary file!",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Yes, delete it!",
                    cancelButtonText: "No, cancel plx!",
                    closeOnConfirm: false,
                    closeOnCancel: false },
                function(isConfirm){
                    if (isConfirm) {
                        $.ajax({
                            type: 'DELETE',
                            url: url+id,
                            data: {id: id},
                            success:function(data){
                                var datatable = $('.dataTableUser').DataTable();
                                datatable.row($('.alerts').parents('tr')).remove().draw();
                            }
                        });
                        swal("Deleted!", "Your imaginary file has been deleted.", "success");
                    }
                    else {
                        swal("Cancelled", "Your imaginary file is safe :)", "error");
                    }
                });
        });

        $(document).on('click', '.alerts', function(e){
            var url = $(this).data("url");
            var id = $(this).data("id");
            e.preventDefault();
            swal({   title: "Are you sure?",
                    text: "You will not be able to recover this imaginary file!",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Yes, delete it!",
                    cancelButtonText: "No, cancel plx!",
                    closeOnConfirm: false,
                    closeOnCancel: false },
                function(isConfirm){
                    if (isConfirm) {
                        $.ajax({
                            type: 'DELETE',
                            url: url+id,
                            data: {id: id},
                            success:function(data){
                                var datatable = $('.dataTableCity').DataTable();
                                datatable.row($('.alerts').parents('tr')).remove().draw();
                            }
                        });
                        swal("Deleted!", "Your imaginary file has been deleted.", "success");
                    }
                    else {
                        swal("Cancelled", "Your imaginary file is safe :)", "error");
                    }
                });
        })
    } );
    function printDiv(divName) {
        var printContents = document.getElementById(divName).innerHTML;
        var originalContents = document.body.innerHTML;

        document.body.innerHTML = printContents;

        window.print();

        document.body.innerHTML = originalContents;
    }

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    // Load Image
    $('#image-selecter').change(function(){

        let reader = new FileReader();
        reader.onload = (e) => {
            $('#image_preview_container').attr('src', e.target.result);
        };
        reader.readAsDataURL(this.files[0]);

    });
    // Load Logo
    $('#image-logo').change(function(){

        let reader = new FileReader();
        reader.onload = (e) => {
            $('#image_preview_container_logo').attr('src', e.target.result);
        };
        reader.readAsDataURL(this.files[0]);

    });
    // Modal add user Store
    $('#submit_user').on('submit', function(e) {
        e.preventDefault();
        var form_data = new FormData(this);
        var datatable = $('#dataTableUser').DataTable();
        if(typeof(name) != "undefined" && name !== null){
            $.ajax({
                type: "POST",
                dataType: "json",
                url: '{{url('add_user')}}',
                data: form_data,
                cache:false,
                processData: false,
                contentType: false,
                success: function(data){
                    // console.log(data);
                    $('#add_user').modal('close');
                    $(".name").val('');
                    $(".email").val('');
                    $(".phone").val('');
                    $(".image").val('');
                    $('#image_preview_container').attr('src', '{{ asset("image/user_avatar.png") }}');
                    $(".password").val('');
                    if(data['status'] == 1){
                        // console.log(data);
                        datatable.clear();
                        var i;
                        for (i = 0; i < data['data'].length; i++) {
                            datatable.row.add( [
                                i+1,
                                data['data'][i].name,
                                data['data'][i].email,
                                data['data'][i].phone,
                                '<img src="' + data['data'][i].image + '">'
                            ] ).draw(false);
                        }
                        swal("{{trans('admin.Inserted Successfully!')}}", "", "success");
                    } else {
                        swal("{{trans('admin.ERROR!')}}", data['message'], "error");
                    }
                },
                error: function(data){
                    swal("{{trans('admin.ERROR!')}}", data['message'], "error");
                }
            });
        }
    });
    // Modal Edit User Show
    $(document).on('click', '.get_edit', function() {
        var id = $(this).attr("data-id");
        console.log(id);
        $.ajax({
            type: "POST",
            dataType: "json",
            url: '{{url('get_user')}}',
            data: {'id': id},
            success: function(data){
                console.log(data);
                $(".edit_name").val(data.name);
                $(".edit_email").val(data.email);
                $(".edit_phone").val(data.phone);
                $(".edit_image").attr('src', '{{ asset('data.image') }}');
                $('.edit_user').modal('open');
            }
        });
    });

    //-----------------------------------------------------------------------

    // Modal add City Store
    $('#submit_city').on('submit', function(e) {
        e.preventDefault();
        var form_data = new FormData(this);
        var datatable = $('.dataTableCity').DataTable();
        $.ajax({
            type: "POST",
            dataType: "json",
            url: '{{url('add_city')}}',
            data: form_data,
            cache:false,
            processData: false,
            contentType: false,
            success: function(data){
                console.log(data);
                $('#add_city').modal('close');
                $(".city_name").val('');
                if(data['status'] == 1){
                    // console.log(data);
                    datatable.clear();
                    var i;
                    for (i = 0; i < data['data'].length; i++) {
                        var trDOM = datatable.row.add( [
                            i+1,
                            data['data'][i].name,
                            '<a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan edit_city" data-id="'+data['data'][i].id+'"><i class="material-icons">mode_edit</i></a>',
                            '<a class="btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange alerts" data-url="{{asset('delete_city')}}/" data-id="'+data['data'][i].id+'"><i class="material-icons">clear</i></a>'
                        ] ).draw(false).node();
                        $( trDOM ).addClass(''+data['data'][i].id);
                    }
                    swal("{{trans('admin.Inserted Successfully!')}}", "", "success");
                } else {
                    swal("{{trans('admin.ERROR!')}}", data['message'], "error");
                }
            },
            error: function(data){
                swal("{{trans('admin.ERROR!')}}", data['message'], "error");
            }
        });
    });

    // Modal Edit City Show
    $(document).on('click', '.edit_city', function() {
        var id = $(this).attr("data-id");
        console.log(id);
        $.ajax({
            type: "POST",
            dataType: "json",
            url: '{{url('edit_city')}}',
            data: {'id': id},
            success: function(data){
                console.log(data);
                $(".city_id").val(data[0].id);
                $(".city_name_first").val(data[0].name);
                $(".city_name_second").val(data[1].name);
                $('#edit_city').modal('open');
            }
        });
    });

    $('#update_city').on('submit', function(e) {
        e.preventDefault();
        var form_data = new FormData(this);
        var datatable = $('.dataTableCity').DataTable();
        $.ajax({
            type: "POST",
            dataType: "json",
            url: '{{url('update_city')}}',
            data: form_data,
            cache:false,
            processData: false,
            contentType: false,
            success: function(data){
                console.log(data);
                $('#edit_city').modal('close');
                $(".city_name").val('');
                if(data['status'] == 1){
                    // console.log(data);
                    datatable.clear();
                    var i;
                    for (i = 0; i < data['data'].length; i++) {
                        var trDOM = datatable.row.add( [
                            i+1,
                            data['data'][i].name,
                            '<a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan edit_city" data-id="'+data['data'][i].id+'"><i class="material-icons">mode_edit</i></a>',
                            '<a class="btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange alerts" data-url="{{asset('delete_city')}}/" data-id="'+data['data'][i].id+'"><i class="material-icons">clear</i></a>'
                        ] ).draw(false);
                        $( trDOM ).addClass(''+data['data'][i].id);
                    }
                    swal("{{trans('admin.Inserted Successfully!')}}", "", "success");
                } else {
                    swal("{{trans('admin.ERROR!')}}", data['message'], "error");
                }
            },
            error: function(data){
                swal("{{trans('admin.ERROR!')}}", data['message'], "error");
            }
        });
    });



//-----------------------------------------------------


    // Modal add Area Store
    $('#submit_area').on('submit', function(e) {
        e.preventDefault();
        var form_data = new FormData(this);
        var datatable = $('.dataTableArea').DataTable();
        $.ajax({
            type: "POST",
            dataType: "json",
            url: '{{url('add_area')}}',
            data: form_data,
            cache:false,
            processData: false,
            contentType: false,
            success: function(data){
                console.log(data);
                $('#add_area').modal('close');
                $(".area_name").val('');
                if(data['status'] == 1){
                    // console.log(data);
                    datatable.clear();
                    var i;
                    for (i = 0; i < data['data'].length; i++) {
                        var trDOM = datatable.row.add( [
                            i+1,
                            data['data'][i].name,
                            data['data'][i].city_name,
                            '<a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan edit_area" data-id="'+data['data'][i].id+'"><i class="material-icons">mode_edit</i></a>',
                            '<a class="btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange alerts" data-url="{{asset('delete_area')}}/" data-id="'+data['data'][i].id+'"><i class="material-icons">clear</i></a>'
                        ] ).draw(false).node();
                        $( trDOM ).addClass(''+data['data'][i].id);
                    }
                    swal("{{trans('admin.Inserted Successfully!')}}", "", "success");
                } else {
                    swal("{{trans('admin.ERROR!')}}", data['message'], "error");
                }
            },
            error: function(data){
                swal("{{trans('admin.ERROR!')}}", data['message'], "error");
            }
        });
    });

    // Modal Edit Area Show
    $(document).on('click', '.edit_area', function() {
        var id = $(this).attr("data-id");
        console.log(id);
        $.ajax({
            type: "POST",
            dataType: "json",
            url: '{{url('edit_area')}}',
            data: {'id': id},
            success: function(data){
                console.log(data);
                $(".area_id").val(data[0].id);
                $(".area_name_first").val(data[0].name);
                $(".area_name_second").val(data[1].name);
                $('#edit_area').modal('open');
            }
        });
    });

    $('#update_area').on('submit', function(e) {
        e.preventDefault();
        var form_data = new FormData(this);
        var datatable = $('.dataTableArea').DataTable();
        $.ajax({
            type: "POST",
            dataType: "json",
            url: '{{url('update_area')}}',
            data: form_data,
            cache:false,
            processData: false,
            contentType: false,
            success: function(data){
                console.log(data);
                $('#edit_area').modal('close');
                $(".area_name").val('');
                if(data['status'] == 1){
                    // console.log(data);
                    datatable.clear();
                    var i;
                    for (i = 0; i < data['data'].length; i++) {
                        var trDOM = datatable.row.add( [
                            i+1,
                            data['data'][i].name,
                            data['data'][i].city_name,
                            '<a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan edit_area" data-id="'+data['data'][i].id+'"><i class="material-icons">mode_edit</i></a>',
                            '<a class="btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange alerts" data-url="{{asset('delete_area')}}/" data-id="'+data['data'][i].id+'"><i class="material-icons">clear</i></a>'
                        ] ).draw(false);
                        $( trDOM ).addClass(''+data['data'][i].id);
                    }
                    swal("{{trans('admin.Inserted Successfully!')}}", "", "success");
                } else {
                    swal("{{trans('admin.ERROR!')}}", data['message'], "error");
                }
            },
            error: function(data){
                swal("{{trans('admin.ERROR!')}}", data['message'], "error");
            }
        });
    });


    // ---------------------------------------------------------------------

    // Modal add Category Store
    $('#submit_category').on('submit', function(e) {
        e.preventDefault();
        var form_data = new FormData(this);
        var datatable = $('.dataTableCategory').DataTable();
        $.ajax({
            type: "POST",
            dataType: "json",
            url: '{{url('add_category')}}',
            data: form_data,
            cache:false,
            processData: false,
            contentType: false,
            success: function(data){
                console.log(data);
                $('#add_category').modal('close');
                $(".category_name").val('');
                if(data['status'] == 1){
                    // console.log(data);
                    datatable.clear();
                    var i;
                    for (i = 0; i < data['data'].length; i++) {
                        var trDOM = datatable.row.add( [
                            i+1,
                            data['data'][i].name,
                            '<img src="' + data['data'][i].image + '">',
                            '<a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan edit_city" data-id="'+data['data'][i].id+'"><i class="material-icons">mode_edit</i></a>',
                            '<a class="btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange alerts" data-url="{{asset('delete_category')}}/" data-id="'+data['data'][i].id+'"><i class="material-icons">clear</i></a>'
                        ] ).draw(false).node();
                        $( trDOM ).addClass(''+data['data'][i].id);
                    }
                    swal("{{trans('admin.Inserted Successfully!')}}", "", "success");
                } else {
                    swal("{{trans('admin.ERROR!')}}", data['message'], "error");
                }
            },
            error: function(data){
                swal("{{trans('admin.ERROR!')}}", data['message'], "error");
            }
        });
    });

    // Modal Edit Category Show
    $(document).on('click', '.edit_category', function() {
        var id = $(this).attr("data-id");
        console.log(id);
        $.ajax({
            type: "POST",
            dataType: "json",
            url: '{{url('edit_category')}}',
            data: {'id': id},
            success: function(data){
                console.log(data);
                $(".category_id").val(data[0].id);
                $(".old_image").val(data[0].image);
                $(".category_name_first").val(data[0].name);
                $(".category_name_second").val(data[1].name);
                $('#edit_category').modal('open');
            }
        });
    });

    $('#update_category').on('submit', function(e) {
        e.preventDefault();
        var form_data = new FormData(this);
        var datatable = $('.dataTableCategory').DataTable();
        $.ajax({
            type: "POST",
            dataType: "json",
            url: '{{url('update_category')}}',
            data: form_data,
            cache:false,
            processData: false,
            contentType: false,
            success: function(data){
                console.log(data);
                $('#edit_category').modal('close');
                $(".category_name").val('');
                if(data['status'] == 1){
                    // console.log(data);
                    datatable.clear();
                    var i;
                    for (i = 0; i < data['data'].length; i++) {
                        var trDOM = datatable.row.add( [
                            i+1,
                            data['data'][i].name,
                            '<img src="' + data['data'][i].image + '">',
                            '<a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan edit_category" data-id="'+data['data'][i].id+'"><i class="material-icons">mode_edit</i></a>',
                            '<a class="btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange alerts" data-url="{{asset('delete_category')}}/" data-id="'+data['data'][i].id+'"><i class="material-icons">clear</i></a>'
                        ] ).draw(false);
                        $( trDOM ).addClass(''+data['data'][i].id);
                    }
                    swal("{{trans('admin.Inserted Successfully!')}}", "", "success");
                } else {
                    swal("{{trans('admin.ERROR!')}}", data['message'], "error");
                }
            },
            error: function(data){
                swal("{{trans('admin.ERROR!')}}", data['message'], "error");
            }
        });
    });


    // -----------------------------------------------------------------------


    // Modal add Brand Store
    $('#submit_brand').on('submit', function(e) {
        e.preventDefault();
        var form_data = new FormData(this);
        var datatable = $('.dataTableBrand').DataTable();
        $.ajax({
            type: "POST",
            dataType: "json",
            url: '{{url('add_brand')}}',
            data: form_data,
            cache:false,
            processData: false,
            contentType: false,
            success: function(data){
                console.log(data);
                $('#add_brand').modal('close');
                $(".brand_name").val('');
                if(data['status'] == 1){
                    // console.log(data);
                    datatable.clear();
                    var i;
                    for (i = 0; i < data['data'].length; i++) {
                        var trDOM = datatable.row.add( [
                            i+1,
                            data['data'][i].name,
                            '<a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan edit_brand" data-id="'+data['data'][i].id+'"><i class="material-icons">mode_edit</i></a>',
                            '<a class="btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange alerts" data-url="{{asset('delete_brand')}}/" data-id="'+data['data'][i].id+'"><i class="material-icons">clear</i></a>'
                        ] ).draw(false).node();
                        $( trDOM ).addClass(''+data['data'][i].id);
                    }
                    swal("{{trans('admin.Inserted Successfully!')}}", "", "success");
                } else {
                    swal("{{trans('admin.ERROR!')}}", data['message'], "error");
                }
            },
            error: function(data){
                swal("{{trans('admin.ERROR!')}}", data['message'], "error");
            }
        });
    });

    // Modal Edit City Show
    $(document).on('click', '.edit_brand', function() {
        var id = $(this).attr("data-id");
        console.log(id);
        $.ajax({
            type: "POST",
            dataType: "json",
            url: '{{url('edit_brand')}}',
            data: {'id': id},
            success: function(data){
                console.log(data);
                $(".brand_id").val(data[0].id);
                $(".brand_name_first").val(data[0].name);
                $(".brand_name_second").val(data[1].name);
                $('#edit_brand').modal('open');
            }
        });
    });

    $('#update_brand').on('submit', function(e) {
        e.preventDefault();
        var form_data = new FormData(this);
        var datatable = $('.dataTableBrand').DataTable();
        $.ajax({
            type: "POST",
            dataType: "json",
            url: '{{url('update_brand')}}',
            data: form_data,
            cache:false,
            processData: false,
            contentType: false,
            success: function(data){
                console.log(data);
                $('#edit_brand').modal('close');
                $(".brand_name").val('');
                if(data['status'] == 1){
                    // console.log(data);
                    datatable.clear();
                    var i;
                    for (i = 0; i < data['data'].length; i++) {
                        var trDOM = datatable.row.add( [
                            i+1,
                            data['data'][i].name,
                            '<a class="btn-floating waves-effect waves-light gradient-45deg-light-blue-cyan edit_brand" data-id="'+data['data'][i].id+'"><i class="material-icons">mode_edit</i></a>',
                            '<a class="btn-floating waves-effect waves-light gradient-45deg-purple-deep-orange alerts" data-url="{{asset('delete_brand')}}/" data-id="'+data['data'][i].id+'"><i class="material-icons">clear</i></a>'
                        ] ).draw(false);
                        $( trDOM ).addClass(''+data['data'][i].id);
                    }
                    swal("{{trans('admin.Inserted Successfully!')}}", "", "success");
                } else {
                    swal("{{trans('admin.ERROR!')}}", data['message'], "error");
                }
            },
            error: function(data){
                swal("{{trans('admin.ERROR!')}}", data['message'], "error");
            }
        });
    });



    //----------------------------------------------------------------------


    // $('.give_id').hover(
    //     function() {
    //         $( this ).addClass( "hover" );
    //     }, function() {
    //         $( this ).removeClass( "hover" );
    //     }
    // ).on('click', function () {
    //     var id = $(this).data("id");
    //     // $(this).toggleClass('hoverTwo');
    //     $('.get_edit').removeAttr('disabled').attr("data-id", id);
    // });

    // $('.get_edit').on('change', function () {
    //     if($('.give_id').hasClass('hoverTwo')){
    //         $(this).removeAttr('disabled').attr("data-id", id);
    //     } else {
    //         $(this).attr('disabled', 'disabled').attr("data-id", null);
    //     }
    // });



    // $('.give_id').on('click', function() {
    //     var id = $(this).data("id");
    //     // $(this);
    //
    //     console.log(id);
    //     $('.get_edit').removeAttr('disabled').attr("data-id", id);
    //
    // });



</script>
